/**
 * Created by admin on 2017/4/19.
 */
window.onload=function(){
    $('.partner').on('click',function(){
        // alert(1);
        $('.partner').addClass('.active');
    })
}